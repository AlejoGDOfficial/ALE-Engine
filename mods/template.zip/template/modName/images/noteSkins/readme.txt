This is where you're supposed to put your Note Skins.
Note skins need 2 files with the same names:

NOTE_assets-my_skin.png
NOTE_assets-my_skin.xml

To add your note skin to the list, make a list.txt file on this folder and add your skin name, if you want to add multiple skins, do it like this:

My Skin 1
My Skin 2
My Skin 3